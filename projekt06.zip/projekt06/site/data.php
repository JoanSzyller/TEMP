<?php

$login = 'admin';
$pass = 'admin';

$towary = array(
    array(1, 'Klawiatura', 10.99),
    array(2, 'Kamerka', 100.67),
    array(3, 'Monitor', 349.00),
    array(4, 'Komputer PC', 1099.99),
    array(5, 'Myszka komputerowa', 7.99)
);

?>