    <script src="./js/bootstrap.min.js"></script>    
    <script src="./JS/script.js"></script>
</body>
</html>    
