<?php

?>    

<?php include './site/header.php'; ?>

    <div class="container">
            <div class="row">
                <h1 class="text-center">Panel logowania</h1>
            <div>
        </div>

<?php include './site/footer.php'; ?>


